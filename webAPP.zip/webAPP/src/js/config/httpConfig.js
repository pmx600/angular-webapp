/**
 * Created by pmx on 2017/3/12.
 */
angular.module('app')
.config(['$sceDelegateProvider',function ($sceDelegateProvider) {

    $sceDelegateProvider.resourceUrlWhitelist([
        'self',
        'http://localhost/api/**'
    ]);

}]);