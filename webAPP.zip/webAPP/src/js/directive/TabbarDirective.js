/**
 * Created by pmx on 2017/3/12.
 */
angular.module('app').directive('tabbar',function () {

    return{
        restrict:'A',
        templateUrl:'../view/template/tabbar_tpl.html',
        replace:true,
    }

});