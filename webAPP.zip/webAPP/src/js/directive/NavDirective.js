/**
 * Created by pmx on 2017/3/11.
 */
angular.module('app').directive('nav',function () {

    return{
        restrict:'A',
        templateUrl:'../view/template/nav_tpl.html',
        replace:true,
        /*
        * $scope:作用域
        * $jqLite:jQuery对象
        * $attrs:获取属性属性
        * */
        link:function ($scope,$jqLite,$attrs) {
            $jqLite.find('span').html($attrs.nav);
            console.log($attrs.ishidden);
            if ($attrs.ishidden == "true"){
                $jqLite.find('em').css({display:'none'});
            }
        }
    }

});