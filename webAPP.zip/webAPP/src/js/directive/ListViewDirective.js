/**
 * Created by pmx on 2017/3/12.
 */
angular.module('app').directive('listView',function () {

    return{
        restrict:'A',
        templateUrl:'../view/template/listview_tpl.html',
        replace:true,
    }

});